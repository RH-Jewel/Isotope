(function ($) {


    //Isotope
    $(".items_wrappers").isotope({
        itemSelector: '.single_item'
    });

    $('ul.click_menu li').on('click', function () {

        $("ul.click_menu li").removeClass("active");
        $(this).addClass("active");

        var selector = $(this).attr('data-filter');
        $(".items_wrappers").isotope({
            filter: selector,
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false,
            }
        });
        return false;
    });
    

})(jQuery);